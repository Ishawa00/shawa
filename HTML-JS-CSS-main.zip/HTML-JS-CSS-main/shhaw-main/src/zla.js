const wrapper = document.querySelector(".sliderWrapper");
const menuItems = document.querySelectorAll(".menuItem");


const shopItemsData = [
  {
    id: "thyfhcbcv",
    name: "C4 pre-workout",
    price: 300,
    desc: "Take your C4 and smash your gym",
    img: "images/c4.jpeg",
  },
 {
    id: "tddd",
    name: "SCULPTnation-preworkout",
    price: 30,
    desc: "Full of caffine =full of power.",
    img: "images/sculp.jpeg",},

    {id: "tddhyud",
    name: "Serious mass",
    price: 30,
    desc: "super gainer to add a lot of kgs to your wight .",
    img: "images/R.jpeg",},

    {id: "tduydud",
    name: "Whey protien",
    price: 30,
    desc: "Get your protein with low carb & fat .",
    img: "images/OIP.jpeg"},

    {id: "tuydud",
    name: "short",
    price: 30,
    desc: "get your shorts from us .",
    img: "images/shorts.jpeg",
 
 

  }
];


